/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package webapp;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

/**
 *
 * @author Administrator
 */
public class database{
    database() throws Exception{
        Class.forName("org.apace.derby.jdbc.ClientDriver");
        Connection con= DriverManager.getConnection("jdbc:derby://localhost:1527/absi", "absi", "absi");
        Statement st = con.createStatement();
        ResultSet rs = st.executeQuery("select * From USERS");
            while(rs.next()){
            System.out.println("<tr>");
            System.out.println("<td>\" "+rs.getString("username")+"\"</td>");
            System.out.println("<td>\" "+rs.getString("password")+"\"</td>");
            System.out.println("</tr>");

}
    }
}
